﻿namespace sagarlib;

public class Class1
{

}
