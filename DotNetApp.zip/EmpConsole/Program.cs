﻿// See https://aka.ms/new-console-template for more information
using EmpLib;
using System;

Person Rohit = new Person();
Rohit.Name = "Rohit";
Console.WriteLine(Rohit.Eat());


Person Sagar = new Person();
Sagar.Name = "Sagar";
Console.WriteLine(Sagar.Work());
Person Vidya = new Employee() { /*Empid = 1001,*/ Designation = "Intern", DOJ = DateTime.Now.AddMonths(-1) };
Vidya.Name = "Vidya";
((Employee)Vidya).Designation = "Analyst";
Console.WriteLine(Vidya.Work());
//added below line to check set
Console.WriteLine($"Empid for {Vidya.Name} is {((Employee)Vidya).Empid}");
Console.WriteLine(((Employee)Vidya).AttendTraining ("C2C"));


//polymorphism
RuntimePolymorphism sharmaji_F = new RuntimePolymorphism();
Console.WriteLine($"Sharmaji's Father :{sharmaji_F.Settle()}");
Console.WriteLine($"Sharmaji's Father got married :{sharmaji_F.GetMarried()}");
Console.WriteLine("---------------------------------------------");
Console.WriteLine($"Shrmaji_F father concept of drawing(using abstract): {sharmaji_F.Drawing()}");
Console.WriteLine($"Shrmaji_F father concept of Dating(using abstract): {sharmaji_F.WhatisDating()}");

Console.WriteLine("***************************************************");

RuntimePolymorphism Sharmaji = new Child();
Console.WriteLine($"Shramaji :{Sharmaji.Settle()}");
Console.WriteLine($"Sharma ji gets married :{Sharmaji.GetMarried()}");
Console.WriteLine("---------------------------------------------");
Console.WriteLine($"Shrmaji_F father concept of drawing(using abstract): {sharmaji_F.Drawing()}");
Console.WriteLine($"Shrmaji_F father concept of Dating(using abstract): {sharmaji_F.WhatisDating()}");

///calling the function of abstract calss ie from Telent(we will get the output directly by using the object of father class 
Console.WriteLine($"output is:{Sharmaji.GetDetails()}");

    
//no Virtual, modification disallowed by class, force modify using "new" keyword
Console.WriteLine("***************************************************");
Child SharmajiV2 = new Child();
Console.WriteLine($"Sharmaji_V2 gets married :{SharmajiV2.GetMarried()}");


//see overrloading that is compiled time polymorphism below
Employee Vidyasagar = new Employee(); 
Vidyasagar.Name= "Vidyasagar";
Vidyasagar.Designation = "Security System Analyst";
Console.WriteLine(Vidyasagar.Work());
Console.WriteLine(Vidyasagar.Work("Solveing bugs"));

//exposing non-pblic information through publiuc methods 
Employee Srikar = new Employee();
Srikar.Name = "Srikar";
Srikar.SetTaxInfo("I'm eligible in the 20% tax payer category");
Console.WriteLine(Srikar.GetTaxInfo());


//Test calling one constructor from another

Person Raghu =new Person("AA2536237b382", "+91 6362623623");
//this constructor should call the constructor that sets aadhar number
Console.WriteLine($"AAdhar: Raghu: {Raghu.Aadhar} | MobileNumber:{Raghu.MobileNumber}");



Console.WriteLine($"Total Employee count:{EmpUtils.EmpCount}");

///Adding employee to a temporary db - using static list<Employee>
EmpUtils.EmpDB.Add(Srikar);//We will get an error so we neee to do some changes in EmpUtils
EmpUtils.EmpDB.Add(Vidyasagar);
EmpUtils.EmpDB.Add(new Employee("AAS66278bsnj", "+91 6363637474") { Name = "Param", Designation = "Analyst", salary = 600000 });
EmpUtils.EmpDB.Add(new Employee("BD3746348bdfh", "+91 7263637474") { Name = "Pavan", Designation = "TAX Tech", salary = 700000 });
EmpUtils.EmpDB.Add(new Employee("BD3746348bdfh", "+91 7263637474") { Name = "Manoj", Designation = "Cloud Analyst", salary = 800000 });


//Get all employee whose aadhar card starts with AA

 var resultlist =EmpUtils.EmpDB.Where((emp) => emp.Aadhar!=null && emp.Aadhar.StartsWith("AA"));
resultlist.ToList().ForEach((emp) => Console.WriteLine($"{emp.Name} | {emp.Aadhar}"));

//get all employee with salary greater that 6L

var resultlist1 = EmpUtils.EmpDB.Where((emp) => emp.salary != null && emp.salary>(600000));
resultlist1.ToList().ForEach((emp) => Console.WriteLine($"{emp.Name} | {emp.salary}"));









