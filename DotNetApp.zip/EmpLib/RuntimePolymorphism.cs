﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLib
{
    public class RuntimePolymorphism : Talent
    {
        //Premitting different ligic in derived
        public virtual string Settle()
        {
            return "Get a Government Job, Reteire by 60yrs and Settle in native";
        }
        public string GetMarried()
        {
            return "Match horscope, marry person from same religion, caste,settle in joint family";

        }
        //call abstract  functions  from talent class below ie in father class
        public override string Drawing()
        {
            return "Drawing portrates, Tanjore Painting";
        }
        public override string WhatisDating()
        {
            return "Meeting friends at restorant";  
        }

        
    }
    public class Child : RuntimePolymorphism 
    {
        public override string Settle()
        {
            string howtoLive = "Get a fat salaried job in fortune 500 company , Visit different countries, live outside hometoen";
            howtoLive = $"{howtoLive} and later folow this :{base.Settle()}";
            return howtoLive;
        }

        //function hiding
        new public string GetMarried()
        {
            return "Register marriage, Surprise parents and settle abroad ";
        }
        //call abstract  functions  from talent class below ie in child class
        public override string Drawing()
        {
            return "drawing abstract art, Mandala art";
        }
        public override string WhatisDating()
        {
            return "use tinder app";
        }
    }

    //abstract == Incomplete
    public abstract class Talent
    {
        public abstract string WhatisDating();
        public abstract String Drawing();

        public string GetDetails()
        {
            return "vidya:21"; 
        }
          
        
    }
}
