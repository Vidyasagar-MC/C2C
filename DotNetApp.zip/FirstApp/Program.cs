﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Diagnostics;
using System.Security.Cryptography;

Vidyasagar();
ConversionOfType();
void Vidyasagar ()
{
    Console.WriteLine("Hello, World!");
//working with datatypes
int num1 = 100;
int num2 = 100;
    Console.WriteLine("sum=" + (num1 + num2));
    //declaration -alternate way
    var num3 = 200;
    Console.WriteLine(num3.GetType().Name);
    var formattedFloat = 200f;
    var formattedDouble = 200d;
    var formattedDecimal = 200m;
    Console.WriteLine(formattedFloat.GetType().Name);
    Console.WriteLine(formattedDouble.GetType().Name);
    Console.WriteLine(formattedDecimal.GetType().Name);
    Console.WriteLine("Vidya" + "sagar");

    //concatenation using string interpolation
    Console.Write($"The datatype of num3 is {num3.GetType().Name}");
    Console.WriteLine("datatype is" + num3.GetType().Name);
    Console.WriteLine($" the datatype of formattedFloat is {formattedFloat.GetType().Name }");

//other types
bool isEverythingOk = true;
string greetMessage = "hello welcometo c# training session";
char ianSingle = 'S';

    Console.WriteLine($"Value of {nameof(isEverythingOk)} is {isEverythingOk}");
}

void ConversionOfType()
{
    int num1 = 100;
    double num2= 100;
    bool isEverythingOk = true;
    string str = "Hello";
    string strNum = "100";


    var result1= (double)num1;
    var result2 = (int)num2;
    //var result3 = (int)isEverythingOk; //string on heap and bool on stack. Hence error in casting

    var convert1 = Convert.ToString(num1);
    var convert2 = Convert.ToInt32(strNum);
    //var convert2=conert.ToInt32(str);  //error at runtime
    Console.WriteLine(str);
}

void WorikingWithArray()
{
    int[] arr = new int[3];
    arr[0] = 10;
    arr[1] = 20;
    arr[2] = 30;
    int i= 0;
    for (i = 0; i < arr.Length; i++)
    {
       
        Console.WriteLine($"value of item: {arr[i]}");

    }
  
    string[] greetings = { "Namaste", "Hello", "Namaskara" };
    int counter = 0;
    while (counter <greetings.Length)
    {
        Console.WriteLine($"A new way to greet:{greetings[counter]}");
        counter++;
    }
    int[] evens = { 2, 4, 6, 8, 10 };
    object[] objArray = { 100, "ok", new int[] { 1, 2, 3 } };
    counter = 0;
    do
    {
       Console.WriteLine($"the next even number:{evens[counter]}");
        counter++;
    }while(counter<evens.Length);

    foreach (var singleitem in objArray)
    {
        if(singleitem.GetType().Name=="Int32[]")
        {
            foreach (var item in (Int32[])singleitem)
            {
                Console.WriteLine(item);
            }

        }
        else
        {
            Console.WriteLine($"simple item in {nameof(objArray)}:{singleitem}");
        }
    }

}
    WorikingWithArray();



//working with lists

WorkingWithLists();
void WorkingWithLists()
{
    List<string> shoppingList = new List<string>();
    Console.WriteLine($"Total items in shopping bag :{shoppingList.Count()}");
    shoppingList.Add("Bags");
    log(new object[] { "Item Added", shoppingList[0] });
    shoppingList.Add("Shoes");
    log(new object[] { "Item Added", shoppingList[1] });
    shoppingList.Add("shirts");
    log(new object[] { "Item Added", shoppingList[2] });


    //generic for Log
    shoppingList.Add("Bags");
    Log(new object[] { "Item Added", shoppingList[0] });
    PrintValues(shoppingList);
   // Console.WriteLine($"shoppingList items :{shoppingList[0]}");
    //Console.WriteLine($"shoppingList items :{shoppingList[1]}");
    Console.WriteLine($"Total Items in Shooping bag:{shoppingList.Count()}");
    shoppingList.Remove("Shoes");
      log(new object[] { "Item removed","Shoes" });
    Console.WriteLine( $"Total items in shopping bag :{shoppingList.Count()}");

    // to call function print
    Print(new object[] {"comma-separarted vakues of the shopping list",
                             shoppingList[0],
                             shoppingList[1],
                             "\n the total count of items is:",
                             shoppingList.Count ()});
    // to call generic function
    Print1(new object[] {"comma-separarted vakues of the shopping list",
                             shoppingList[0],
                             shoppingList[1],
                             "\n the total count of items is:",
                             shoppingList.Count ()});

}

//creating separate generic function to dispaly the contents or the itms inside shoppingList
//
void PrintValues<T>(List <T> pCollection)
{
    //use code snippet
    foreach (var item in pCollection)
    {
        Console.WriteLine(item);
    }
}
 
void Print(object[] pValues)// we use object when we need multiple datatypes
{
    string result = "";
    foreach (var item in pValues)
    {
        result = $"{result},{item}";
    }
    result = result.TrimStart(',');
    Console.WriteLine(result);
}

///geenric function
void Print1<T>(T[] pValues)
{
    string result = "";
    foreach (var item in pValues)
    {
        result = $"{result},{item}";
    }
    result = result.TrimStart(',');
    Console.WriteLine(result);
}


//11-02-2023:12:18:00.0:Toatal item added is 3
void log(object[] pValues)
{
    string result="";
    foreach ( var item in pValues)
    {
        result = $"{result} {item}";

    }
    var finalResult = $"[{DateTime.Now.ToString()}]: {result}";
    //console logging
    Console.ForegroundColor = ConsoleColor.DarkYellow;
    
    Console.WriteLine("------");
    Console.WriteLine(finalResult);

    //output
    Debug.WriteLine("---LOG--");
    Debug.WriteLine(finalResult);
}

//generic for log
void Log<T>(T[] pValues)
{
    string result = "";
    foreach (var item in pValues)
    {
        result = $"{result} {item}";

    }
    var finalResult = $"[{DateTime.Now.ToString()}]: {result}";
    //console logging
    Console.ForegroundColor = ConsoleColor.DarkBlue;

    Console.WriteLine("------");
    Console.WriteLine(finalResult);

    //output
    Debug.WriteLine("---LOG--");
    Debug.WriteLine(finalResult);
}

Utils obejcts =new Utils();
class Utils
{

}


