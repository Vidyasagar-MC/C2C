using EmpLib;

namespace EmpForms
{
    public partial class Form1 : Form// partial means this class contains functions in different classes or in different files

    {
        Employee kpmgemp = new Employee();
        public Form1()
        {
            InitializeComponent();
            button1.Click += button1_Click2;
            button1.Click += button1_Click3;

            kpmgemp.Join += Rohit_Join;//after += press tab to get Vidyasagar_Join
            kpmgemp.Join += Srikar_Join;
            kpmgemp.Join += Lekha_Join;

            kpmgemp.Resign += Srikar_Resign;
            kpmgemp.Resign += Rohit_Resign;
           

        }

        private void Srikar_Resign(object? sender, EventArgs e)
        {
            MessageBox.Show("Srikar resigned kpmg");
        }

        private void Rohit_Resign(object? sender, EventArgs e)
        {
            MessageBox.Show("Rohit resigned kpmg");
        }

       

       

        
       
        private void Rohit_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Rohit joined kpmg");
        }
        private void Srikar_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Srikar joined kpmg");
        }
        private void Lekha_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Lekha joined kpmg");
        }

        private void Vidyasagar_Join(object? sender, EventArgs e)
        {
            /* MessageBox.Show("Vidya joined KPMG successfully");*/
            // kpmgemp.Join.Invoke(null, null);
            //Rohit_Join(null, null);
            // Srikar_Join(null, null);
            // Lekha_Join(null, null);
            kpmgemp.TriggerJoinEvent();
        }
       



        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("I am subscriber 1 of click event");
        }
        private void button1_Click2(object sender, EventArgs e)
        {
            MessageBox.Show("I am subscriber 2 of click event");
        }
        private void button1_Click3(object sender, EventArgs e)
        {
            MessageBox.Show("I am subscriber 3 of click event");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Vidyasagar_Join(new Employee("Afdsyghruy65476", "+91 987654653"), null);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            kpmgemp.TriggerResignEvent();
        }
    }
}