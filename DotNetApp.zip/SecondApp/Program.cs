﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, vidya!");
Console.WriteLine("Add these Number:"+ (5+5));
