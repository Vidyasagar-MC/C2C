﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLib
{
    public class EmpUtils
    {
        public  static List<Employee> EmpDB {get; set;}  = new List<Employee>();//
                                                                                //=new should be added when we get an error
        public static int EmpCount {  get; set; }
       

        public static void Log<T>(T[] pValues)
        {
            string result = "";
            foreach (var item in pValues)
            {
                result = $"{result} {item}";

            }
            var finalResult = $"[{DateTime.Now.ToString()}]: {result}";
            //console logging
            Console.ForegroundColor = ConsoleColor.DarkBlue;

            Console.WriteLine("------");
            Console.WriteLine(finalResult);

            //output
            Debug.WriteLine("---LOG--");
            Debug.WriteLine(finalResult);
        }

    }
}
