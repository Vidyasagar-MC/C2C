﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLib
{
    /// <summary>
    /// inside interface by default the access speifier will be public
    /// </summary>
    public interface EmployeeContract
    {
        void ViewContract();
        void Sign();//we can have default void implementation in c#/dotnet
    }
}
