﻿using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace EmpLib 
{ 
    
    public class Employee : Person, EmployeeContract
    
    {
        //creating an event
        public event EventHandler Join;
        public event EventHandler Resign;
        //ctor and press tab a shortcut for constructor
        // call base class constructor
        public Employee():base()
        {
            this.ViewContract();
            this.Sign();
            this.Empid = new Random(1000).Next();
            //Access utility function
            EmpUtils.EmpCount++;
        }


        //trigger join method which contains lots of menthods

        public void TriggerJoinEvent()
        {
            this.Join.Invoke(this, null);
        }

        //resign event 
        public void TriggerResignEvent()
        {
            this.Resign.Invoke(this, null);
        }

        //call current class's other constructor
        //overloading constructor below(same function name but different parameters
        public Employee (string pAadhar): this()
        {
            this.Aadhar = pAadhar;
        }
        //in program.cs : Employee you=new Employee ("aadhar number ", "+91 3643483479")

        public Employee(string pAadhar, string pMobile):base(pAadhar,pMobile)
        {
            this.ViewContract();
            this.Sign();
            this.Empid = new Random(1000).Next();
            // Access utility function
            EmpUtils.EmpCount++;
        }

        
        // Vraiables indside a class are known as FIELDS
        private bool _contractSIgned=false;
        private bool _hasReadContract = false;
        
        private int _empid;
        public int Empid { get { return _empid; } 
            private set { _empid = value; } }
        public string Designation { get; set; }
        public double salary { get; set; }
        public DateTime DOJ { get; set; }
        public bool IsActive { get; set; }
        public string AttendTraining(string pTraining) 
        {
            return $"{this.Name} attended a training {pTraining}";
        }
        public string FillTimesheet(List<string> ptasks) {
            var csvTask = "";
            foreach (var task in ptasks)
            {
                csvTask = $"{csvTask},{task}";
            }
            return $"{this.Name} has work on {csvTask} on {DateTime.Now.ToShortDateString()}";




        }

        //below is an example of real time polymorphism ie. overriden is an example of RTP
        public override string Work()
        {
            return $"{this.Name} with {this.Empid} work for 8hrs a day at KPMG";
        }

        public string Work(string task)
        {
            return $"{this.Name} with {this.Empid} has {task} assigned on {DateTime.Today}";
        }

        public void Sign()
        {
            _contractSIgned = true;
        }

        public void ViewContract()
        {
            _hasReadContract = true;
        }

        public void SetTaxInfo(string pTaxInfo)
        {
            this.TaxDetails = pTaxInfo;
        }

        public string GetTaxInfo()
        {
            return $"{this.Name}:yors tax details are:{this.TaxDetails}";
        }
    }
}
