﻿// See https://aka.ms/new-console-template for more information


using System;
using System.Security.Cryptography.X509Certificates;

partial class Program
{
    //Declaration=  new Datatype
    delegate void Compute(int n1, int n2);
    delegate void Contractor(double budget);
    delegate void Work(string vs, bool t );
    static void Main()
    {
        //Instantiate
        ///using ACTION
        Action<string,bool> Work1= new Action<string,bool>(
            (vs,t) =>
            {
                Console.WriteLine($"work is:{vs} and {t}");
            }
            );
        Work1("Coding in c#",true);

        Func<string, string> work2 = (name1) => $"The name is:{name1}";
        work2 += (name1) => $"The name is:{name1}";

        Console.WriteLine(work2("Vidya"));

        Predicate<int> upDB = (V) =>
        {
            if (V == 1) return true;
            else return false;
        };
        Console.WriteLine($"Employee set isActive:{upDB(1)}");


        /*Predicate<string> updateDB = () =>
        {
            if (updateDB == 1) return true;
            else return false;
        };
        Console.WriteLine($"Output of predicate:{updateDB(1)}");*/

        /*Func<int, int, string> modifieedCompute = (n1, n2) => $"Addition: {n1 + n2}";
        modifieedCompute += (n1, n2) => $"Subtraction: {n1 - n2}";
         * Compute objShortCompute = new Compute((a,b) => Console.WriteLine($"Addition: {a+b}") );
        objShortCompute += (s, t) => Console.WriteLine($"Subtraction: {s - t}");
        objShortCompute += (s, t) => Console.WriteLine($" Multiplication: {s * t}");
        objShortCompute += (s, t) => Console.WriteLine($"Divison: {s / t}");


        //Invocation like calling a function
        objShortCompute(250, -50);*/
    }

    private static void UseingGenericDelegates()
    {
        Action<double> RockRaniMarriage = new Action<double>(
                    (budget) =>
                    {
                        Console.WriteLine($"Reagistration charges:{budget * 95 / 100}");
                        Console.WriteLine($"Reception charges:{budget * 5 / 100}");
                    }
                    );
        //USING FUNCTION
        Func<int, int, string> modifieedCompute = (n1, n2) => $"Addition: {n1 + n2}";
        modifieedCompute += (n1, n2) => $"Subtraction: {n1 - n2}";

        //USING PREDICATE
        Predicate<int> isActive = (V) =>
        {
            if (V == 0) return false;
            else return true;
        };

        //INVOKE ALL ABOVE DELIGATES(ACTION.FUNCTION,PREDICATE) 
        RockRaniMarriage(5000000d);
        Console.WriteLine(modifieedCompute(100, 200));
        Console.WriteLine($"Output of predicate:{isActive(1)}");
    }

    private static void RockRaniMarriage()
    {
        Contractor RockyRaniMarrige = new Contractor((b) => Console.WriteLine($"Pandit charges: {b * 20 / 100}"));
        RockyRaniMarrige += (b) => Console.WriteLine($"Catering Charges: {b * 50 / 100}");
        RockyRaniMarrige += (b) => Console.WriteLine($"Mandap Decoration: {b * 5 / 100}");
        RockyRaniMarrige += (b) => Console.WriteLine($"Couple arrive in Oorsche reserved for 2 days: {b * 15 / 100}");

        //Get Rocky and Rani married viz.Invocation like calling a function
        RockyRaniMarrige(1000000000);
    }

    private static void UsingLambdas()
    {
        Compute objShortCompute = new Compute((a, b) => Console.WriteLine($"Addition: {a + b}"));
        objShortCompute += (s, t) => Console.WriteLine($"Subtraction: {s - t}");
        objShortCompute += (s, t) => Console.WriteLine($" Multiplication: {s * t}");
        objShortCompute += (s, t) => Console.WriteLine($"Divison: {s / t}");


        //Invocation like calling a function
        objShortCompute(250, -50);
    }

    private static void DelegatesUsingLongCutTechnique()
    {
        Compute objCompute = new Compute(AddFn);
        objCompute += SubFn;
        objCompute += MulFn;
        objCompute += DivFn;

        //Invoke the delegate exactly like a function
        objCompute(300, 200);
    }


    static void AddFn(int n1, int n2)
    {
        Console.WriteLine($" Output of Addition :{n1 + n2}");
    }

    static void SubFn(int n1, int n2)
    {
        Console.WriteLine($" Output of Subtract :{n1 - n2}");
    }

    static void MulFn(int n1, int n2)
    {
        Console.WriteLine($" Output of Multiple :{n1 * n2}");
    }

    static void DivFn(int n1, int n2)
    {
        Console.WriteLine($" Output of dvidion :{n1 / n2}");
    }
}
